function __Styles(){
	animationTextStyle = {
		fontSize:16,
		fillColor:new RgbColor(1,1,1,0.9),
        font:"cursive"
	}
	interactionTextStyle = {
		fontSize:16,
		fillColor:new RgbColor(0,0,0)
	}
    if(navigator.appName == "Microsoft Internet Explorer"){
		animationTextStyle.font = "arial";
	}
}
var Animation = {
	images:[
		{
			id:'board',
			src:'/assets/animations/board_green.jpg'
		}
	],
	init:function(container){
			Animation.container = container;
			var w=$(container).width(), h=$(container).height();
			var board = new Raster('board');
			board.position = new Point(w*0.5,h*0.5+2)
			var referencePoint = new Point(250,40);
            var p1 = referencePoint.add(0,0);
			var p2 = referencePoint.add(0,50);
			var p3 = referencePoint.add(0,100);
			//SingleLineMultiply(p1,100,'0',4519,1,animationTextStyle);
			SingleLineMultiply({
                position:p1,
                delay:100,
                factor1:4519,
                factor2:1,
                zero:'0',
                textStyle:animationTextStyle
            });
            SingleLineMultiply({
                position:p2,
                delay:5000,
                factor1:4519,
                factor2:1,
                zero:'00',
                textStyle:animationTextStyle
            });
            SingleLineMultiply({
                position:p3,
                delay:10000,
                factor1:4519,
                factor2:1,
                zero:'000',
                textStyle:animationTextStyle
            });
//            SingleLineMultiply(p2,4000,'00',4519,1,animationTextStyle);
//			SingleLineMultiply(p3,8000,'000',4569,1,animationTextStyle);
            setTimeout(Main.animationFinished,15000);
		}
}
var Interaction = {
	getFramework:function(){
			return 'paper';
		},
	init:function(container){
			Interaction.container = container;
			Main.setObjective('Yandaki çarpma işlemini zihinden yapınız ve sonucu kontrol ediniz.');
			Interaction.paper = {
				width:$(container).width(),
				height:$(container).height()
			}
			
			Interaction.appendInput({
				position:'relative',
				width:'120px',
				top:'-2px',
				fontSize:'20px',
				height:'35px'
			});
			$(Interaction.input).attr('maxlength','7')
			var div = document.createElement('div');
			$(container).append(div);
			$(div)
				.css({
					position:'absolute',
					top:100,
					right:200,
					lineHeight:'40px',
					fontSize:'20px',
					width:'300px',
					height:'50px',
					letterSpacing:'1px',
					textAlign:'right'
				})
				.html('<span id="factor1"></span>&nbsp;×&nbsp;<span id="factor2"></span>&nbsp;=&nbsp;')
				.append(Interaction.input);
			Interaction.questionDiv = div;
			Interaction.factor1Span = $('span#factor1',div).get(0);
			Interaction.factor2Span = $('span#factor2',div).get(0);
			Interaction.appendButton({
				bottom:'40px',
				right:'40px'
			});
			Interaction.appendStatus({
				bottom:'50px',
				right:'170px'
			})
			
			Interaction.prepareNextQuestion();
		},
	nextQuestion: function(){
            Main.interactionProject.activeLayer.removeChildren();
			if(Interaction.solutionDiv)
				$(Interaction.solutionDiv).remove();
				
			Interaction.factor1 = Math.floor(Math.random()*10000);
			Interaction.factor2 = Math.pow(10,Math.floor(Math.random()*3+1)); 
			$(Interaction.factor1Span).html(Util.groupNumber(Interaction.factor1));
			$(Interaction.factor2Span).html(Util.groupNumber(Interaction.factor2));
			
		},
	isAnswerCorrect : function(value){
			if(value == Interaction.factor1 * Interaction.factor2)
				return true;
			else 
				return false;
		},
	onCorrectAnswer : function(){
			
		},
	onWrongAnswer : function(){
			
		},
	onFail : function(){
			Interaction.pause = true;
			Interaction.setStatus('Yanlış cevap, doğrusu ' +  Util.groupNumber(Interaction.factor1 * Interaction.factor2) + ' olacaktı',false);
			Interaction.solutionDiv = $(Interaction.questionDiv).clone().insertAfter(Interaction.questionDiv);
			var zeros = $('#factor2',Interaction.questionDiv).html();
			zeros = zeros.substring(1,zeros.length); 
            SingleLineMultiply({
                position:new Point(160,200),
                delay:10,
                factor1:Interaction.factor1,
                factor2:(""+Interaction.factor2).substring(0,1),
                zero:zeros,
                textStyle:interactionTextStyle,
                callback:function(){
                    Interaction.pause = false;
                }
            });
//			SingleLineMultiply(new Point(160,200),10,zeros,Interaction.factor1,(""+Interaction.factor2).substring(0,1),interactionTextStyle);
		}
}
;
